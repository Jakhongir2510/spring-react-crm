import React from "react";

export default function DashboardPage() {
  return (
    <div>
      <h2>Dashboard</h2>
      <p>Welcome to the CRM system! 👋</p>
    </div>
  );
}


package com.example.crm.service;

import com.example.crm.model.Customer;
import com.example.crm.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository repository;

    public List<Customer> getAllCustomers() {
        return repository.findAll();
    }

    public Optional<Customer> getCustomer(Long id) {
        return repository.findById(id);
    }

    public Customer createCustomer(Customer customer) {
        return repository.save(customer);
    }

    public Customer updateCustomer(Long id, Customer updatedCustomer) {
        return repository.findById(id).map(c -> {
            c.setName(updatedCustomer.getName());
            c.setEmail(updatedCustomer.getEmail());
            c.setPhone(updatedCustomer.getPhone());
            c.setStatus(updatedCustomer.getStatus());
            return repository.save(c);
        }).orElseGet(() -> {
            updatedCustomer.setId(id);
            return repository.save(updatedCustomer);
        });
    }

    public void deleteCustomer(Long id) {
        repository.deleteById(id);
    }
}
